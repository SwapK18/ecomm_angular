import { Component, OnInit } from '@angular/core';
import { CommonService } from '../__services/common.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  catId: number | undefined;

  constructor(private servCommon: CommonService, private actRte: ActivatedRoute) { }

  ngOnInit() {
    this.catId = parseInt(this.actRte.snapshot.params['catId']);
    this.servCommon.getProducts(this.catId).subscribe((ret) => {
      console.log(ret);
    });

  }
}
