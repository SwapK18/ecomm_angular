import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const AUTH_API = "http://localhost:9000/";
const httpOptions = {
  headers: new HttpHeaders({
    "Content-Type": "application/json",
  })
};

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http: HttpClient) { }

  getSocialDetails(): Observable<any> {
    return this.http.get(AUTH_API + "api/social", httpOptions);
  }

  getPageSettings(): Observable<any> {
    return this.http.get(AUTH_API + "api/settings", httpOptions);
  }

  getTopNavigation(): Observable<any> {
    return this.http.get(AUTH_API + "api/topnav", httpOptions);
  }

  getHomeSlider(): Observable<any> {
    return this.http.get(AUTH_API + "api/homeslider", httpOptions);
  }

  getServices(): Observable<any> {
    return this.http.get(AUTH_API + "api/homeservices", httpOptions);
  }

  getFeaturedProducts(): Observable<any> {
    return this.http.get(AUTH_API + "api/featuredproducts", httpOptions);
  }

  getProds(): Observable<any> {
    return this.http.get(AUTH_API + "api/prods", httpOptions);
  }

  getNewsletter(): Observable<any> {
    return this.http.get(AUTH_API + "api/newsletter", httpOptions);
  }

  getProducts(pCatId: number): Observable<any> {
    return this.http.get(AUTH_API + "api/products/" + pCatId, httpOptions);
  }
}
