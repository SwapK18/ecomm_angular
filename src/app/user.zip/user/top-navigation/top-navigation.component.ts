import { Component, OnInit } from '@angular/core';
import { CommonService } from '../__services/common.service';

@Component({
  selector: 'app-top-navigation',
  templateUrl: './top-navigation.component.html',
  styleUrls: ['./top-navigation.component.css']
})
export class TopNavigationComponent implements OnInit {
  data: any;
  topNav: any;
  menuHtml: any;

  categoryMulti: any = {
    categories: {},
    parent_cats: {}
  };

  constructor(private servCommon: CommonService) {

  }


  ngOnInit(): void {
    this.servCommon.getTopNavigation().subscribe(ret => {
      this.data = ret;

      for (var i = 0; i < (this.data).length; i++) {
        this.categoryMulti.categories[this.data[i].category_id] = this.data[i];
        if (!this.categoryMulti.parent_cats[this.data[i].parent_id]) {
          this.categoryMulti.parent_cats[this.data[i].parent_id] = [];
        }
        this.categoryMulti.parent_cats[this.data[i].parent_id].push(this.data[i].category_id);
      }

      this.menuHtml = this.listCategoryTree(0, this.categoryMulti);
    });
  }

  listCategoryTree(parent: any, category: any) {
    const css_class = (parent === 0 ? "parent" : "child");
    let html = ''; let arr;
    if (category.parent_cats[parent]) {
      html += '<ul>' + "\n";

      // category.parent_cats[parent].forEach(cat_id => {
      arr = category.parent_cats[parent];
      for (let i = 0; i < arr.length; i++) {
        if (!category.parent_cats[arr[i]]) {
          html += `<li id="">\n`;

          html += `<a [routerLink]="['/products', ${category.categories[arr[i]].category_id}]" data-cap="css_class-${arr[i]}">${category.categories[arr[i]].category_name}</a>\n`;

          html += `</li>` + `\r`;

        } else {
          html += '<li id="">\n';

          
          
          // html += '<a [routerLink]="[/products,'+ category.categories[arr[i]].category_id + ']" data-cap="' + css_class + '-' + arr[i] + '">' + category.categories[arr[i]].category_name + '</a>' + "\r";
          
          
          html += `<a [routerLink]="['/products', ${category.categories[arr[i]].category_id}]" data-cap="css_class-${arr[i]}">${category.categories[arr[i]].category_name}</a>\r`;
          
          

          html += this.listCategoryTree(arr[i], category);
          html += `</li>` + `\r`;
        }
      }
      html += `</ul>` + `\n`;
    }
    return html;
  }
}
