import { Component, OnInit, numberAttribute } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '../__services/_common/common.service';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { AuthService } from '../__services/_auth/auth.service';
import Swal from 'sweetalert2';

const Toast = Swal.mixin({
  toast: true,
  position: "top-end",
  showCloseButton: true,
  showConfirmButton: false,
  timer: 3000,
  didOpen: (toast) => {
    toast.addEventListener("mouseenter", Swal.stopTimer);
    toast.addEventListener("mouseleave", Swal.resumeTimer);
  },
});

@Component({
  selector: 'app-prod-detail',
  templateUrl: './prod-detail.component.html',
  styleUrls: ['./prod-detail.component.css']
})
export class ProdDetailComponent implements OnInit {
  prdId!: number;
  arrProducts: any[] = [];
  objVar: any = {};
  objCat: any = {};
  objPrd: any = {};
  lclObjPrd: any = {};
  objPrdVar: any = [];
  finalCombination: string = '';
  addToCart!: FormGroup;

  constructor(private authServ: AuthService, private fb: FormBuilder, private commServ: CommonService, private actRte: ActivatedRoute, private hhtpc: HttpClient, private rtr: Router) {
    this.createForm();
  }
  ngOnInit(): void {

    this.prdId = parseInt(this.actRte.snapshot.params['prdId']);
    this.commServ.getProductsByProdId(this.prdId).subscribe((ret: any): void => {
      this.arrProducts = ret.data;

      console.log(this.arrProducts);
      

      this.objPrd = {
        'product_id': this.arrProducts[0].product_id,
        'product_name': this.arrProducts[0].prd_name,
        'product_description': this.arrProducts[0].prd_description,
        'product_is_featured': this.arrProducts[0].is_featured,
        'product_is_active': this.arrProducts[0].is_active,
        'variations': [],
        'categories': [],
        'skus': [],
        'regular_price': [],
        'spcl_offr_discount_factor': [],
        'spcl_offr_max_quantity': [],
        'spcl_offr_min_quantity': [],
        'spcl_offr_price': [],
        'stock': [],
        'p_image': [],
        'featured_image': this.arrProducts[0].featured_image
      };


      for (var i = 0; i < (this.arrProducts.length); i++) {
        const elPrd = this.arrProducts[i];
        console.log(elPrd);
        

        // for variations

        for (let j = 0; j < elPrd.vars.length; j++) {
          const elVariations = elPrd.vars[j];
          let lclNameIdComb: { [key: string]: any } = {};

          if (!this.objVar.hasOwnProperty(elVariations.var_p)) {
            this.objVar[elVariations.var_p] = [];
          }

          const varChildSet = new Set(this.objVar[elVariations.var_p].map((item: any) => item.var_name));

          if (!varChildSet.has(elVariations.var_child)) {
            lclNameIdComb['var_id'] = elVariations.var_child_id;
            lclNameIdComb['var_name'] = elVariations.var_child;

            this.objVar[elVariations.var_p].push(lclNameIdComb);
          }

          this.objPrd['variations'].push(this.objVar);

        }


        // for categories
        for (var k = 0; k < ((elPrd.cats).length); k++) {
          const elCats = elPrd.cats[k];
          if (!this.objCat.hasOwnProperty(elCats.cat_parent)) {
            this.objCat[elCats.cat_parent] = [];
          }
          if (!(this.objCat[elCats.cat_parent]).includes(elCats.cat_child)) {
            (this.objCat[elCats.cat_parent]).push(elCats.cat_child);
          }
          this.objPrd['categories'].push(this.objCat);
        }

        // for categories
        this.objPrd['skus'].push(this.arrProducts[i].sku);
        this.objPrd['regular_price'].push(this.arrProducts[i].regular_price);
        this.objPrd['spcl_offr_discount_factor'].push(this.arrProducts[i].spcl_offr_discount_factor);
        this.objPrd['spcl_offr_max_quantity'].push(this.arrProducts[i].spcl_offr_max_quantity);
        this.objPrd['spcl_offr_min_quantity'].push(this.arrProducts[i].spcl_offr_min_quantity);
        this.objPrd['spcl_offr_price'].push(this.arrProducts[i].spcl_offr_price);
        this.objPrd['stock'].push(this.arrProducts[i].stock);
        this.objPrd['p_image'].push(this.arrProducts[i].p_image);
        this.objPrd['categories'].push(this.objCat);
      }


    }, (err: Error): any => {
      throw "Error encountered " + err;
    });
  }

  getObjectKeys(obj: any): string[] {
    return Object.keys(obj);
  }

  getObjectValues(obj: any, key: string): any[] {
    return obj[key];
  }

  onSave(pKey: any, pValue: any): void {
    let combinations: any = [];
    let lenKeys: any;
    this.lclObjPrd[pKey] = pValue;

    var sortedObj: any = {};
    Object.keys(this.lclObjPrd).sort().forEach((key) => {
      sortedObj[key] = this.lclObjPrd[key];
    });

    var result = "";
    this.finalCombination = "";

    for (var key in sortedObj) {
      result += sortedObj[key] + "-";
      this.finalCombination += sortedObj[key] + "-";
    }

    result = result.slice(0, -1);
    this.finalCombination = (this.finalCombination).slice(0, -1);

    this.commServ.getProductsByVariants(this.finalCombination).subscribe((data: any): any => {
      this.objPrdVar = data.data;

    }, (err: Error): any => {
      throw 'Something went wrong ' + err
    });
  }


  createForm() {
    this.addToCart = this.fb.group({
      p_qty: [''],
      product_variants_id: [''],
      p_name: ['']
    });

    console.log(this.addToCart.value);
  }

  onSubmit(f: FormGroup) {
    let ifAlreadyLoggedIn: boolean = false;
    ifAlreadyLoggedIn = this.authServ.isLoggedIn();

    if (ifAlreadyLoggedIn === false) {
      // alert message and go back to previous page
      this.alertConfirmation('error', 'Login first', 'center-end');
      this.rtr.navigate(['/user/login']);
    } else {
      this.commServ.addToCart(this.prdId, f.value.product_variants_id, f.value.p_qty).subscribe((data) => {
        console.log(data);
        this.alertConfirmation('info', 'Product added successfully!', 'center-end');
      });
    }

  }

  alertConfirmation(p_typ: any, p_msg: any, p_pos: any = null) {
    Swal.fire({
      position: p_pos,
      icon: p_typ,
      title: "Login message",
      text: p_msg,
      toast: true,
      timer: 6000,
      showConfirmButton: false,
      background: "#fbfbfb",
      showCloseButton: true
    });
  }
}
