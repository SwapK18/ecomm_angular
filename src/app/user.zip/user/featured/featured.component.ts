import { Component, OnInit } from '@angular/core';
import { CommonService } from '../__services/common.service';

@Component({
  selector: 'app-featured',
  templateUrl: './featured.component.html',
  styleUrls: ['./featured.component.css']
})
export class FeaturedComponent implements OnInit {
  feat_product: any;
  settings: any;
  prods: any;

  constructor(private servCommon: CommonService) { }

  ngOnInit(): void {
    this.servCommon.getFeaturedProducts().subscribe((ret) => {
      this.feat_product = ret;
    });

    this.servCommon.getPageSettings().subscribe((ret)=>{
      this.settings = ret;
    });
  }

}
