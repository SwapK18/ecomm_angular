import { Component, OnInit } from '@angular/core';
import { CommonService } from '../__services/common.service';

@Component({
  selector: 'app-home-slider',
  templateUrl: './home-slider.component.html',
  styleUrls: ['./home-slider.component.css']
})
export class HomeSliderComponent implements OnInit {
  slider: any;
  constructor(private servCommon: CommonService) { }
  ngOnInit(): void {
    this.servCommon.getHomeSlider().subscribe((ret) => {
      this.slider = ret;
    });
  }
}
