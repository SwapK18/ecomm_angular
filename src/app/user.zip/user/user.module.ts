import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { HomeComponent } from './home/home.component';
import { UserRootComponent } from './user-root/user-root.component';
import { HeaderComponent } from './header/header.component';
import { TopNavigationComponent } from './top-navigation/top-navigation.component';
import { HomeSliderComponent } from './home-slider/home-slider.component';
import { HttpClientModule } from '@angular/common/http';
import { FooterComponent } from './footer/footer.component';
import { ServicesComponent } from './services/services.component';
import { FeaturedComponent } from './featured/featured.component';
import { ProductsComponent } from './products/products.component';
import { NewsletterComponent } from './newsletter/newsletter.component';


@NgModule({
  declarations: [
    HomeComponent,
    UserRootComponent,
    HeaderComponent,
    TopNavigationComponent,
    HomeSliderComponent,
    FooterComponent,
    ServicesComponent,
    FeaturedComponent,
    ProductsComponent,
    NewsletterComponent],
  imports: [
    CommonModule,
    UserRoutingModule,
    HttpClientModule
  ]
})
export class UserModule { }
